(function () {
  window.NUVORA_CONTENT = {
    services: ['website', 'landing', 'redesign', 'multipage', 'deployment'],
    packages: ['package-1', 'package-2', 'package-3'],
    extras: ['revisions', 'pages', 'features', 'backend', 'maintenance'],
    portfolioCategories: ['all', 'demo'],
    portfolioProjects: [
      { id: 'west-coffee', category: 'demo', image: 'images/portfolio/west-coffee.webp', url: 'https://nuvorawebdev-ofc.github.io/Demo-website-by-Nuvora-01/' },
      { id: 'drasa-restaurant', category: 'demo', image: 'images/portfolio/drasa-restaurant.webp', url: 'https://nuvorawebdev-ofc.github.io/Demo-website-02/' },
      { id: 'assyifa-dental-clinic', category: 'demo', image: 'images/portfolio/assyifa-dental-clinic.webp', url: 'https://nuvorawebdev-ofc.github.io/Demo-website-03/' }
    ],
    routes: {
      home: '',
      portfolio: 'portfolio/',
      privacy: 'privacy-policy/',
      thankyou: 'thank-you/',
      notFound: '404.html'
    }
  };
})();
