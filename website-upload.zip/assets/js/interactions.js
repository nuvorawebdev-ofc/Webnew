(function () {
  function initReveal() {
    const nodes = document.querySelectorAll('.reveal:not(.is-visible)');
    if (!('IntersectionObserver' in window)) { nodes.forEach((node) => node.classList.add('is-visible')); return; }
    const observer = new IntersectionObserver((entries, instance) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) { entry.target.classList.add('is-visible'); instance.unobserve(entry.target); }
      });
    }, { threshold: 0.12 });
    nodes.forEach((node) => observer.observe(node));
  }

  function initFaq() {
    document.querySelectorAll('[data-faq-question]').forEach((button) => button.addEventListener('click', () => {
      const item = button.closest('[data-faq-item]');
      const panel = item.querySelector('[data-faq-answer]');
      const expanded = button.getAttribute('aria-expanded') === 'true';
      document.querySelectorAll('[data-faq-item]').forEach((other) => {
        const otherButton = other.querySelector('[data-faq-question]');
        const otherPanel = other.querySelector('[data-faq-answer]');
        otherButton.setAttribute('aria-expanded', 'false');
        otherPanel.hidden = true;
        other.classList.remove('is-open');
      });
      if (!expanded) {
        button.setAttribute('aria-expanded', 'true');
        panel.hidden = false;
        item.classList.add('is-open');
      }
    }));
  }

  function initSmoothLinks() {
    document.querySelectorAll('a[href^="#"]').forEach((link) => link.addEventListener('click', (event) => {
      const id = link.getAttribute('href');
      const target = document.querySelector(id);
      if (target) { event.preventDefault(); target.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
    }));
  }

  function initYear() {
    document.querySelectorAll('[data-year]').forEach((node) => { node.textContent = new Date().getFullYear(); });
  }

  function init() { initReveal(); initFaq(); initSmoothLinks(); initYear(); }
  window.NuvoraInteractions = { init, initReveal };
})();
