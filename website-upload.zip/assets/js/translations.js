(function () {
  const shared = {
    brand: 'Nuvora.webdev',
    phone: '6285196322176',
    phoneDisplay: '0851 9632 2176',
    email: 'nuvorawebdev@gmail.com',
    instagram: '@nuvora.webdev',
    instagramUrl: 'https://www.instagram.com/nuvora.webdev/',
    siteUrl: 'https://nuvorawebdev.site'
  };

  window.NUVORA_TRANSLATIONS = {
    shared,
    id: {
      meta: {
        home: { title: 'Nuvora.webdev — Website profesional untuk bisnis yang ingin berkembang', description: 'Nuvora membantu bisnis membangun kehadiran digital melalui website yang strategis, modern, dan fungsional.' },
        portfolio: { title: 'Portofolio — Nuvora.webdev', description: 'Jelajahi portofolio dan konsep website Nuvora.webdev.' },
        privacy: { title: 'Kebijakan Privasi — Nuvora.webdev', description: 'Kebijakan privasi Nuvora.webdev yang ditulis dengan bahasa yang jelas dan mudah dipahami.' },
        thankyou: { title: 'Terima kasih — Nuvora.webdev', description: 'Informasi lanjutan setelah Anda memulai percakapan dengan Nuvora.webdev.' },
        notFound: { title: 'Halaman tidak ditemukan — Nuvora.webdev', description: 'Halaman yang Anda cari tidak tersedia.' }
      },
      nav: { home: 'Beranda', services: 'Layanan', pricing: 'Harga', extras: 'Tambahan', portfolio: 'Portofolio', about: 'Tentang', contact: 'Hubungi Kami', menu: 'Buka menu', close: 'Tutup menu', language: 'Bahasa', primary: 'Navigasi utama', chooseLanguage: 'Pilih bahasa' },
      hero: {
        eyebrow: 'NUVORA / DIGITAL PRESENCE',
        headline: 'Website Profesional untuk Bisnis yang Ingin Berkembang.',
        subheadline: 'Nuvora membantu bisnis membangun kehadiran digital melalui website yang dirancang secara strategis, modern, dan fungsional.',
        benefits: ['Desain Premium', 'Desain Strategis', 'Domain Custom', 'Affordable'],
        benefitsLabel: 'Keunggulan Nuvora',
        availability: 'Terbuka untuk proyek baru',
        scroll: 'Jelajahi Nuvora'
      },
      intro: {
        eyebrow: '01 / ARAH YANG JELAS',
        title: 'Kesan pertama yang bekerja lebih keras.',
        body: 'Website bukan sekadar halaman online. Ia adalah ruang pertama tempat calon pelanggan membaca cara Anda bekerja, memahami nilai Anda, dan memutuskan untuk melangkah lebih jauh.',
        accent: 'Buat ruang digital yang terasa sejelas bisnis Anda.'
      },
      services: {
        eyebrow: '02 / LAYANAN',
        title: 'Yang dibutuhkan bisnis untuk terlihat siap.',
        body: 'Kami merancang pengalaman web yang rapi, relevan, dan mudah digunakan—dengan fokus pada kebutuhan nyata bisnis Anda.',
        cta: 'Bahas kebutuhanmu',
        items: [
          { id: 'website', title: 'Desain & Pengembangan Website', description: 'Website yang dirancang dari kebutuhan bisnis dan disusun untuk terasa profesional sejak interaksi pertama.', tag: '01' },
          { id: 'landing', title: 'Pengembangan Landing Page', description: 'Satu halaman yang fokus, ringkas, dan membantu pengunjung memahami tawaran utama Anda.', tag: '02' },
          { id: 'redesign', title: 'Desain Ulang Website', description: 'Penyegaran struktur dan tampilan agar website yang sudah ada terasa lebih jelas dan relevan.', tag: '03' },
          { id: 'multipage', title: 'Website Multi-Halaman', description: 'Ruang digital yang lebih lengkap untuk bisnis dengan beberapa layanan, cerita, atau kebutuhan konten.', tag: '04' },
          { id: 'deployment', title: 'Deployment', description: 'Bantuan menyiapkan dan mempublikasikan website setelah scope, pembayaran, dan kebutuhan teknis terpenuhi.', tag: '05' }
        ]
      },
      pricing: {
        eyebrow: '03 / HARGA',
        title: 'Tiga cara untuk mulai tumbuh.',
        body: 'Semua harga adalah harga mulai. Harga final mengikuti ruang lingkup, kompleksitas, fitur, dan kesiapan konten proyek.',
        note: 'Hosting tidak otomatis termasuk. Domain .my.id tersedia sesuai ketentuan paket.',
        packages: [
          { id: 'package-1', name: 'Starter', description: 'Pilihan profesional untuk kebutuhan satu halaman yang fokus.', price: 'Rp750.000', priceLabel: 'Harga mulai', features: ['1 halaman website', 'Desain custom sesuai kebutuhan bisnis', 'Responsive design', 'Konten website terstruktur', 'Integrasi kontak dan CTA WhatsApp', 'Domain .my.id gratis', '2 kali revisi minor'], cta: 'Tanyakan Starter' },
          { id: 'package-2', name: 'Growth', description: 'Pilihan seimbang untuk bisnis yang membutuhkan beberapa halaman.', price: 'Rp1.990.000', priceLabel: 'Harga mulai', features: ['Hingga 5 halaman website', 'Visual custom yang konsisten', 'Responsive design', 'Navigasi terstruktur', 'Integrasi kontak dan CTA', 'Basic SEO setup', 'Domain .my.id gratis', '2 kali revisi minor'], cta: 'Tanyakan Growth' },
          { id: 'package-3', name: 'Business', description: 'Ruang premium dengan strategi UX dan fitur bisnis yang lebih lengkap.', referencePrice: 'Rp2.790.000', price: 'Rp2.390.000', priceLabel: 'Harga mulai', saving: 'Hemat Rp400.000', features: ['Hingga 5 halaman website', 'Premium custom design', 'Strategi UX berorientasi bisnis', 'Responsive design', 'Struktur website strategis', 'CTA dan lead generation', 'Basic SEO setup', 'Integrasi WhatsApp dan Google Maps', 'Contact form sesuai scope', 'Portfolio, katalog, FAQ, atau testimonial section sesuai kebutuhan', 'Domain .my.id gratis', '2 kali revisi minor', 'Custom WhatsApp Contact Form'], cta: 'Tanyakan Business', featured: true }
        ]
      },
      extras: {
        eyebrow: '04 / TAMBAHAN',
        title: 'Perlu ruang lebih? Tambahkan seperlunya.',
        body: 'Add-on dipilih sesuai kebutuhan proyek. Revisi dan fitur tambahan diproses di luar jatah paket, sementara kebutuhan kompleks memerlukan penilaian teknis terlebih dahulu.',
        items: [
          { id: 'revisions', title: 'Revisi Tambahan', description: 'Minor: Rp58.000 / 1 revisi. Paket 3 revisi minor: Rp89.000. Major: Rp109.000. Minor berarti penyesuaian kecil dalam desain dan scope yang disetujui; major berarti perubahan substansial pada desain atau struktur. Setiap paket sudah memiliki 2 kali revisi minor.', price: 'Mulai Rp58.000' },
          { id: 'pages', title: 'Penambahan Halaman', description: 'Tambahan halaman untuk memperluas konten website ketika kebutuhan bisnis berkembang.', price: 'Rp179.000 / halaman' },
          { id: 'features', title: 'Fitur Tambahan Sederhana', description: 'Contoh: Google Maps, CTA sederhana, integrasi sederhana, atau fungsi WhatsApp sederhana. Tidak mencakup sistem backend kompleks.', price: 'Rp129.000 / fitur · 3 fitur Rp189.000' },
          { id: 'backend', title: 'Backend / Integrasi Kompleks', description: 'Estimasi awal untuk kebutuhan kompleks. Penilaian teknis, scope, dan persetujuan harga diperlukan sebelum pekerjaan dimulai.', price: 'Rp389.000–Rp1.000.000+' },
          { id: 'maintenance', title: 'Maintenance Website', description: 'Opsional dan disepakati terpisah: update konten ringan–menengah, menu, layanan, kontak, jam operasional, teks, gambar pengganti dari klien, dan penyesuaian warna sederhana tanpa redesign penuh.', price: 'Rp119.000 / bulan' }
        ]
      },
      portfolio: {
        eyebrow: '05 / PORTOFOLIO',
        title: 'Tiga demo. Tiga cara bercerita.',
        body: 'Semua karya di sini adalah demo website Nuvora, bukan klaim proyek klien berbayar. Buka preview asli untuk melihat pengalaman lengkapnya.',
        viewAll: 'Lihat portofolio',
        categories: { all: 'Semua', demo: 'Website Demo' },
        filtersLabel: 'Filter portofolio',
        projectLabel: 'DEMO WEBSITE',
        viewProject: 'Lihat website',
        projects: [
          { id: 'west-coffee', title: 'West Coffee', description: 'Konsep website kedai kopi spesialti dengan presentasi menu, storytelling brand, informasi pengunjung, FAQ, dan galeri.' },
          { id: 'drasa-restaurant', title: "D'Rasa Indonesian Restaurant", description: 'Konsep website restoran yang menyajikan kuliner Indonesia, informasi restoran, serta jalur kontak dan reservasi demo.' },
          { id: 'assyifa-dental-clinic', title: 'Assyifa Dental Clinic', description: 'Konsep website klinik gigi yang menyajikan layanan kesehatan, informasi klinik, dan jalur kontak pasien yang mudah diakses.' }
        ]
      },
      process: {
        eyebrow: '06 / CARA KERJA',
        title: 'Jelas sejak percakapan pertama.',
        steps: [
          { number: '01', title: 'Discover', body: 'Pahami bisnis, target audiens, kebutuhan, tantangan, dan tujuan website.' },
          { number: '02', title: 'Define', body: 'Tetapkan scope, struktur halaman, arah visual, fitur, timeline, dan estimasi biaya.' },
          { number: '03', title: 'Design & Build', body: 'Rancang dan kembangkan website berdasarkan brief dan scope yang disetujui.' },
          { number: '04', title: 'Review & Revision', body: 'Klien meninjau website dan mengirim revisi sesuai scope serta jatah revisi.' },
          { number: '05', title: 'Final Payment', body: 'Pelunasan dilakukan setelah pekerjaan disetujui dan sebelum deployment atau publikasi.' },
          { number: '06', title: 'QA & Deployment', body: 'Lakukan pemeriksaan akhir dan publikasikan website setelah pembayaran serta kebutuhan teknis terpenuhi.' },
          { number: '07', title: 'Support', body: 'Dukungan setelah launch mengikuti scope yang disepakati. Maintenance bulanan bersifat opsional.' }
        ]
      },
      terms: {
        eyebrow: '07 / TERMS',
        title: 'Ruang lingkup, pembayaran, dan waktu yang transparan.',
        paymentTitle: 'Payment policy',
        paymentBody: '40% deposit sebelum development dimulai. Sisa 60% dibayarkan setelah pekerjaan disetujui dan sebelum deployment atau publikasi.',
        timelineTitle: 'Estimated timeline',
        timeline: [
          { label: 'Landing Page', value: '3–7 hari kerja' },
          { label: 'Multi-Page Website', value: '3–7 hari kerja' },
          { label: 'Professional Business Website', value: '7–21 hari kerja atau lebih, tergantung kompleksitas' }
        ],
        note: 'Timeline adalah estimasi, bukan jaminan. Durasi final bergantung pada scope, kompleksitas, fitur, kesiapan konten, serta kecepatan feedback dan approval.'
      },
      about: {
        eyebrow: '08 / TENTANG NUVORA',
        title: 'Strategis dalam berpikir. Sederhana dalam pengalaman.',
        body: 'Nuvora.webdev adalah agensi web development yang membantu bisnis dan personal brand membangun kehadiran digital yang profesional, fungsional, dan relevan. Kami memahami masalah sebelum merancang solusi, menghadirkan desain premium dengan harga yang lebih mudah dijangkau, dan menjaga proses tetap jelas serta bertanggung jawab.',
        signal: 'Affordable / Premium / Professional'
      },
      faq: {
        eyebrow: '09 / FAQ',
        title: 'Jawaban sebelum kita mulai.',
        items: [
          { question: 'Berapa biaya pembuatan website?', answer: 'Harga mulai dari Rp750.000 untuk Starter, Rp1.990.000 untuk Growth, dan Rp2.390.000 untuk Business. Harga final mengikuti scope, kompleksitas, fitur, dan kesiapan konten.' },
          { question: 'Apa perbedaan Starter dan Growth?', answer: 'Starter mencakup 1 halaman. Growth mencakup hingga 5 halaman, navigasi terstruktur, dan basic SEO setup.' },
          { question: 'Apa yang termasuk dalam Business?', answer: 'Business mencakup hingga 5 halaman, desain premium, strategi UX, struktur strategis, CTA dan lead generation, basic SEO, integrasi WhatsApp dan Google Maps, contact form sesuai scope, serta custom WhatsApp Contact Form.' },
          { question: 'Berapa lama proses development?', answer: 'Landing Page dan Multi-Page Website diperkirakan 3–7 hari kerja. Professional Business Website diperkirakan 7–21 hari kerja atau lebih, bergantung pada kompleksitas.' },
          { question: 'Apakah revisi termasuk dalam paket?', answer: 'Ya. Setiap paket mencakup 2 kali revisi minor. Revisi tambahan dikenakan biaya sesuai daftar Extras.' },
          { question: 'Apakah fitur tambahan bisa diminta?', answer: 'Bisa. Fitur tambahan sederhana tersedia sebagai add-on. Backend atau integrasi kompleks membutuhkan penilaian teknis dan estimasi terpisah.' },
          { question: 'Apakah website responsive?', answer: 'Ya. Paket website mencakup responsive design untuk perangkat mobile dan desktop.' },
          { question: 'Apakah Nuvora bisa mendesain ulang website yang sudah ada?', answer: 'Bisa. Website Redesign tersedia untuk penyegaran struktur, tampilan, dan pengalaman website sesuai scope yang disepakati.' },
          { question: 'Bagaimana cara memulai proyek?', answer: 'Mulai percakapan melalui WhatsApp. Ceritakan kebutuhan, jenis website, dan konteks bisnis Anda. Kami akan melanjutkan dari informasi yang nyata dan relevan.' },
          { question: 'Apakah domain dan hosting termasuk?', answer: 'Paket mencantumkan domain .my.id gratis sesuai ketentuannya. Hosting tidak otomatis termasuk dan perlu dibahas sesuai kebutuhan deployment.' },
          { question: 'Apakah Nuvora menyediakan SEO?', answer: 'Basic SEO setup dapat termasuk dalam Growth dan Business. Ini bukan jaminan ranking dan bukan layanan manajemen SEO bulanan.' },
          { question: 'Apakah Nuvora menyediakan sistem booking otomatis?', answer: 'Custom WhatsApp Contact Form dapat menyiapkan pesan WhatsApp. Ini bukan CRM, sistem booking otomatis, atau platform reservasi backend.' },
          { question: 'Apakah payment gateway bisa diintegrasikan?', answer: 'Bisa dibahas, tetapi payment gateway memerlukan validasi teknis dan provider. Kebutuhan kompleks memerlukan assessment serta estimasi terpisah.' },
          { question: 'Bagaimana proses pembayarannya?', answer: '40% deposit dibayarkan sebelum development dimulai. Sisa 60% dibayarkan setelah pekerjaan disetujui dan sebelum deployment atau publikasi.' },
          { question: 'Apakah tersedia maintenance bulanan?', answer: 'Ya, maintenance opsional tersedia dengan harga Rp119.000 per bulan untuk update konten ringan hingga menengah sesuai scope.' }
        ]
      },
      contact: {
        eyebrow: '10 / LANGKAH BERIKUTNYA',
        title: 'Mari mulai dari kebutuhan yang nyata.',
        body: 'Sampaikan jenis website, konteks bisnis, dan hal yang ingin Anda capai. Kami akan merespons melalui kanal yang paling nyaman untuk Anda.',
        whatsapp: 'Mulai percakapan WhatsApp',
        email: 'Kirim email',
        instagram: 'Lihat Instagram',
        whatsappLabel: 'WhatsApp Nuvora',
        emailLabel: 'Email Nuvora',
        instagramLabel: 'Instagram Nuvora'
      },
      footer: { tagline: 'Ruang digital yang dirancang untuk bergerak bersama bisnis Anda.', navigation: 'Navigasi', connect: 'Terhubung', copyright: '© {year} Nuvora.webdev. Semua hak dilindungi.', privacy: 'Kebijakan Privasi', thankyou: 'Terima Kasih' },
      buttons: { start: 'Mulai Proyek', portfolio: 'Jelajahi Portofolio', discuss: 'Konsultasikan Kebutuhanmu', backHome: 'Kembali ke Beranda', readPolicy: 'Baca kebijakan privasi', openWhatsApp: 'Buka WhatsApp' },
      privacy: { eyebrow: 'LEGAL / PRIVASI', title: 'Kebijakan Privasi', updated: 'Terakhir diperbarui: 18 November 2026', intro: 'Halaman ini menjelaskan secara sederhana bagaimana Nuvora.webdev memperlakukan informasi ketika Anda menghubungi kami melalui kanal yang tersedia.', sections: [
        { title: 'Informasi yang Anda kirimkan', body: 'Jika Anda menghubungi Nuvora melalui WhatsApp, email, atau Instagram, Anda dapat mengirimkan informasi yang Anda pilih sendiri, seperti nama, detail bisnis, kebutuhan website, dan cara untuk menghubungi Anda.' },
        { title: 'Bagaimana informasi digunakan', body: 'Informasi tersebut digunakan untuk memahami kebutuhan Anda, merespons pertanyaan, dan membahas kemungkinan proyek. Nuvora tidak menjanjikan proses otomatis atau hasil tertentu dari sebuah percakapan.' },
        { title: 'Pihak ketiga dan tautan eksternal', body: 'Tautan WhatsApp, email, dan Instagram membawa Anda ke layanan masing-masing. Penggunaan layanan tersebut tunduk pada kebijakan pihak yang mengoperasikannya.' },
        { title: 'Penyimpanan dan pertanyaan', body: 'Website ini tidak menyediakan akun pengguna atau formulir backend. Jika Anda memiliki pertanyaan tentang informasi yang pernah Anda bagikan, hubungi Nuvora melalui email yang tercantum di website.' }
      ] },
      thankyou: { eyebrow: 'THANK YOU', title: 'Percakapanmu sudah dimulai.', body: 'Terima kasih sudah menghubungi Nuvora. Jika WhatsApp belum terbuka, gunakan tombol di bawah untuk melanjutkan secara manual.', cta: 'Lanjutkan ke WhatsApp', secondary: 'Kembali ke Beranda' },
      notFound: { eyebrow: '404 / TIDAK DITEMUKAN', title: 'Ruang ini belum ada.', body: 'Tautan yang Anda buka mungkin sudah berubah atau belum tersedia. Mari kembali ke halaman utama.', cta: 'Kembali ke Beranda' }
    },
    en: {
      meta: {
        home: { title: 'Nuvora.webdev — Professional websites for businesses ready to grow', description: 'Nuvora helps businesses build a digital presence through strategic, modern, and functional websites.' },
        portfolio: { title: 'Portfolio — Nuvora.webdev', description: 'Explore Nuvora.webdev portfolio work and website concepts.' },
        privacy: { title: 'Privacy Policy — Nuvora.webdev', description: 'Nuvora.webdev privacy policy written in clear, readable language.' },
        thankyou: { title: 'Thank you — Nuvora.webdev', description: 'Next steps after starting a conversation with Nuvora.webdev.' },
        notFound: { title: 'Page not found — Nuvora.webdev', description: 'The page you are looking for is not available.' }
      },
      nav: { home: 'Home', services: 'Services', pricing: 'Pricing', extras: 'Extras', portfolio: 'Portfolio', about: 'About', contact: 'Contact Us', menu: 'Open menu', close: 'Close menu', language: 'Language', primary: 'Primary navigation', chooseLanguage: 'Choose language' },
      hero: {
        eyebrow: 'NUVORA / DIGITAL PRESENCE',
        headline: 'Professional Websites for Businesses Ready to Grow.',
        subheadline: 'Nuvora helps businesses build a digital presence through websites designed to be strategic, modern, and functional.',
        benefits: ['Premium Design', 'Strategic Design', 'Custom Domain', 'Affordable'],
        benefitsLabel: 'Nuvora benefits',
        availability: 'Open for new projects',
        scroll: 'Explore Nuvora'
      },
      intro: {
        eyebrow: '01 / A CLEAR DIRECTION',
        title: 'Make the first impression work harder.',
        body: 'A website is more than an online page. It is the first space where a potential customer reads how you work, understands your value, and decides whether to take the next step.',
        accent: 'Build a digital space that feels as clear as your business.'
      },
      services: {
        eyebrow: '02 / SERVICES',
        title: 'What a business needs to feel ready.',
        body: 'We design web experiences that are focused, relevant, and easy to use—with attention on what your business actually needs.',
        cta: 'Discuss your needs',
        items: [
          { id: 'website', title: 'Website Design & Development', description: 'A website shaped around your business needs and built to feel professional from the first interaction.', tag: '01' },
          { id: 'landing', title: 'Landing Page Development', description: 'One focused page that helps visitors understand your main offer quickly and clearly.', tag: '02' },
          { id: 'redesign', title: 'Website Redesign', description: 'A clearer structure and visual refresh for a website that needs to feel more relevant.', tag: '03' },
          { id: 'multipage', title: 'Multi-Page Website', description: 'A more complete digital space for businesses with several services, stories, or content needs.', tag: '04' },
          { id: 'deployment', title: 'Deployment', description: 'Help preparing and publishing the website after scope, payment, and technical requirements are fulfilled.', tag: '05' }
        ]
      },
      pricing: {
        eyebrow: '03 / PRICING',
        title: 'Three ways to start growing.',
        body: 'All prices are starting prices. Final pricing depends on project scope, complexity, required features, and content readiness.',
        note: 'Hosting is not automatically included. A .my.id domain is available according to package terms.',
        packages: [
          { id: 'package-1', name: 'Starter', description: 'A professional entry-level option for one focused page.', price: 'Rp750.000', priceLabel: 'Starting price', features: ['1 website page', 'Custom design based on business requirements', 'Responsive design', 'Structured website content', 'Contact and WhatsApp CTA integration', 'Free .my.id domain', '2 rounds of minor revisions'], cta: 'Ask about Starter' },
          { id: 'package-2', name: 'Growth', description: 'A balanced option for businesses requiring several pages.', price: 'Rp1.990.000', priceLabel: 'Starting price', features: ['Up to 5 website pages', 'Consistent custom visual design', 'Responsive design', 'Structured navigation', 'Contact and CTA integration', 'Basic SEO setup', 'Free .my.id domain', '2 rounds of minor revisions'], cta: 'Ask about Growth' },
          { id: 'package-3', name: 'Business', description: 'A premium space with UX strategy and more complete business features.', referencePrice: 'Rp2.790.000', price: 'Rp2.390.000', priceLabel: 'Starting price', saving: 'Save Rp400.000', features: ['Up to 5 website pages', 'Premium custom design', 'Business-oriented UX strategy', 'Responsive design', 'Strategic website structure', 'CTA and lead generation', 'Basic SEO setup', 'WhatsApp and Google Maps integration', 'Contact form within agreed scope', 'Portfolio, catalogue, FAQ, or testimonial sections where relevant', 'Free .my.id domain', '2 rounds of minor revisions', 'Custom WhatsApp Contact Form'], cta: 'Ask about Business', featured: true }
        ]
      },
      extras: {
        eyebrow: '04 / EXTRAS',
        title: 'Need more room? Add only what helps.',
        body: 'Choose add-ons around the real project scope. Additional revisions and features sit outside the package allowance, while complex needs require technical assessment first.',
        items: [
          { id: 'revisions', title: 'Additional Revisions', description: 'Minor: Rp58.000 / 1 revision. Pack of 3 minor revisions: Rp89.000. Major: Rp109.000. Minor means small adjustments within approved design and scope; major means substantial changes to design or structure. Every package already includes 2 minor revisions.', price: 'From Rp58.000' },
          { id: 'pages', title: 'Additional Website Pages', description: 'Add pages when the content needs to grow with the business.', price: 'Rp179.000 / page' },
          { id: 'features', title: 'Simple Additional Features', description: 'Examples: Google Maps, simple CTAs, simple integrations, or simple WhatsApp-related functionality. Complex backend systems are not included.', price: 'Rp129.000 / feature · 3 for Rp189.000' },
          { id: 'backend', title: 'Complex Backend / Integration', description: 'An initial estimate for complex requirements. Technical assessment, scope, and approval are required before work begins.', price: 'Rp389.000–Rp1.000.000+' },
          { id: 'maintenance', title: 'Website Maintenance', description: 'Optional and agreed separately: light-to-medium content updates, menu, services, contact details, operating hours, text, client-supplied replacement images, and simple colour adjustments without a full redesign.', price: 'Rp119.000 / month' }
        ]
      },
      portfolio: {
        eyebrow: '05 / PORTFOLIO',
        title: 'Three demos. Three ways to tell a story.',
        body: 'These are Nuvora demo websites, not claims about paying client work. Open the real previews to experience each one in full.',
        viewAll: 'View portfolio',
        categories: { all: 'All', demo: 'Demo Websites' },
        filtersLabel: 'Portfolio filters',
        projectLabel: 'DEMO WEBSITE',
        viewProject: 'View website',
        projects: [
          { id: 'west-coffee', title: 'West Coffee', description: 'A specialty coffee shop website concept featuring menu presentation, brand storytelling, visitor information, FAQ, and gallery.' },
          { id: 'drasa-restaurant', title: "D'Rasa Indonesian Restaurant", description: 'A restaurant website concept presenting Indonesian culinary offerings, restaurant information, and demo contact or reservation pathways.' },
          { id: 'assyifa-dental-clinic', title: 'Assyifa Dental Clinic', description: 'A dental clinic website concept presenting healthcare services, clinic information, and accessible patient contact pathways.' }
        ]
      },
      process: {
        eyebrow: '06 / PROCESS',
        title: 'Clear from the first conversation.',
        steps: [
          { number: '01', title: 'Discover', body: 'Understand the business, audience, needs, challenges, and website objectives.' },
          { number: '02', title: 'Define', body: 'Establish scope, page structure, visual direction, features, timeline, and estimated costs.' },
          { number: '03', title: 'Design & Build', body: 'Design and develop the website from the approved brief and scope.' },
          { number: '04', title: 'Review & Revision', body: 'Review the website and submit revisions within the agreed scope and allowance.' },
          { number: '05', title: 'Final Payment', body: 'Complete the remaining payment after approving the work and before deployment or publication.' },
          { number: '06', title: 'QA & Deployment', body: 'Run final quality checks and publish after payment and technical requirements are fulfilled.' },
          { number: '07', title: 'Support', body: 'Post-launch support follows the agreed scope. Monthly maintenance is optional.' }
        ]
      },
      terms: {
        eyebrow: '07 / TERMS',
        title: 'Clear scope, payment, and timing.',
        paymentTitle: 'Payment policy',
        paymentBody: '40% deposit before development begins. The remaining 60% is paid after the work is approved and before deployment or publication.',
        timelineTitle: 'Estimated timeline',
        timeline: [
          { label: 'Landing Page', value: '3–7 working days' },
          { label: 'Multi-Page Website', value: '3–7 working days' },
          { label: 'Professional Business Website', value: '7–21 working days or longer depending on complexity' }
        ],
        note: 'Timelines are estimates, not guarantees. Final duration depends on scope, complexity, features, content readiness, and feedback or approval speed.'
      },
      about: {
        eyebrow: '08 / ABOUT NUVORA',
        title: 'Strategic in thinking. Simple in experience.',
        body: 'Nuvora.webdev is a web development agency helping businesses and personal brands establish a professional, functional, and relevant digital presence. We understand the problem before designing the solution, deliver premium design at accessible prices, and keep the process clear and responsible.',
        signal: 'Affordable / Premium / Professional'
      },
      faq: {
        eyebrow: '09 / FAQ',
        title: 'Answers before we start.',
        items: [
          { question: 'How much does website development cost?', answer: 'Starting prices are Rp750.000 for Starter, Rp1.990.000 for Growth, and Rp2.390.000 for Business. Final pricing depends on scope, complexity, features, and content readiness.' },
          { question: 'What is the difference between Starter and Growth?', answer: 'Starter includes 1 page. Growth includes up to 5 pages, structured navigation, and basic SEO setup.' },
          { question: 'What is included in Business?', answer: 'Business includes up to 5 pages, premium design, UX strategy, strategic structure, CTA and lead generation, basic SEO, WhatsApp and Google Maps integration, a scoped contact form, and a Custom WhatsApp Contact Form.' },
          { question: 'How long does development take?', answer: 'Landing Page and Multi-Page Website are estimated at 3–7 working days. Professional Business Website is estimated at 7–21 working days or longer depending on complexity.' },
          { question: 'Are revisions included?', answer: 'Yes. Every package includes 2 rounds of minor revisions. Additional revisions are charged according to the Extras list.' },
          { question: 'Can additional features be requested?', answer: 'Yes. Simple additional features are available as add-ons. Complex backend or integrations require technical assessment and a separate estimate.' },
          { question: 'Is the website responsive?', answer: 'Yes. Website packages include responsive design for mobile and desktop devices.' },
          { question: 'Can Nuvora redesign an existing website?', answer: 'Yes. Website Redesign is available for refreshing structure, visual language, and experience within the agreed scope.' },
          { question: 'How do I start a project?', answer: 'Start a WhatsApp conversation. Share your needs, website type, and business context. We will continue from information that is real and relevant.' },
          { question: 'Are domain and hosting included?', answer: 'The package includes a free .my.id domain according to its terms. Hosting is not automatically included and should be discussed for the deployment need.' },
          { question: 'Does Nuvora provide SEO?', answer: 'Basic SEO setup may be included in Growth and Business. It is not a ranking guarantee and is not a monthly SEO management service.' },
          { question: 'Does Nuvora provide automatic booking systems?', answer: 'A Custom WhatsApp Contact Form can prepare a WhatsApp message. It is not a CRM, automated booking system, or backend reservation platform.' },
          { question: 'Can Nuvora integrate payment gateways?', answer: 'It can be discussed, but payment gateways require technical and provider validation. Complex requirements need assessment and a separate estimate.' },
          { question: 'How does the payment process work?', answer: 'A 40% deposit is paid before development begins. The remaining 60% is paid after approval and before deployment or publication.' },
          { question: 'Is monthly maintenance available?', answer: 'Yes. Optional maintenance is available at Rp119.000 per month for light-to-medium updates within the agreed scope.' }
        ]
      },
      contact: {
        eyebrow: '10 / NEXT STEP',
        title: 'Let us start with what is real.',
        body: 'Share your website type, business context, and what you want to achieve. We will respond through the channel that feels most comfortable for you.',
        whatsapp: 'Start a WhatsApp conversation',
        email: 'Send an email',
        instagram: 'View Instagram',
        whatsappLabel: 'Nuvora WhatsApp',
        emailLabel: 'Nuvora email',
        instagramLabel: 'Nuvora Instagram'
      },
      footer: { tagline: 'A digital space designed to move with your business.', navigation: 'Navigation', connect: 'Connect', copyright: '© {year} Nuvora.webdev. All rights reserved.', privacy: 'Privacy Policy', thankyou: 'Thank You' },
      buttons: { start: 'Start a Project', portfolio: 'Explore Portfolio', discuss: 'Discuss Your Requirements', backHome: 'Back to Home', readPolicy: 'Read privacy policy', openWhatsApp: 'Open WhatsApp' },
      privacy: { eyebrow: 'LEGAL / PRIVACY', title: 'Privacy Policy', updated: 'Last updated: November 18, 2026', intro: 'This page explains, in plain language, how Nuvora.webdev treats information when you contact us through the available channels.', sections: [
        { title: 'Information you choose to share', body: 'When you contact Nuvora through WhatsApp, email, or Instagram, you may choose to send information such as your name, business details, website needs, and a way to reach you.' },
        { title: 'How information is used', body: 'That information is used to understand your needs, respond to questions, and discuss a possible project. Nuvora does not promise an automated process or a particular outcome from a conversation.' },
        { title: 'Third parties and external links', body: 'WhatsApp, email, and Instagram links take you to the services that operate them. Their own policies apply to how those services handle information.' },
        { title: 'Storage and questions', body: 'This website does not provide user accounts or a backend form. If you have questions about information you have shared, contact Nuvora through the email listed on the website.' }
      ] },
      thankyou: { eyebrow: 'THANK YOU', title: 'Your conversation has started.', body: 'Thanks for reaching out to Nuvora. If WhatsApp did not open, use the button below to continue manually.', cta: 'Continue in WhatsApp', secondary: 'Back to Home' },
      notFound: { eyebrow: '404 / NOT FOUND', title: 'This space does not exist yet.', body: 'The link may have changed or may not be available. Let us return to the homepage.', cta: 'Back to Home' }
    }
  };
})();
