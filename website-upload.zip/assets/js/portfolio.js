(function () {
  function projectCard(project, locale) {
    const copy = locale.portfolio;
    const text = copy.projects.find((item) => item.id === project.id);
    const base = document.body.dataset.base || '';
    if (!text) return '';
    return `<article class="portfolio-card glass-panel reveal is-visible"><div class="portfolio-card__visual"><img src="${base}assets/${project.image}" alt="${text.title} demo website homepage screenshot" loading="lazy"><span class="portfolio-card__badge">${copy.projectLabel}</span></div><div class="portfolio-card__body"><span class="eyebrow">${copy.projectLabel}</span><h3>${text.title}</h3><p>${text.description}</p><a class="button button--ghost" href="${project.url}" target="_blank" rel="noopener noreferrer">${copy.viewProject}<span aria-hidden="true">↗</span></a></div></article>`;
  }

  function visibleProjects() {
    const activeFilter = document.querySelector('[data-portfolio-filter].is-active')?.dataset.portfolioFilter || 'all';
    return activeFilter === 'all' ? window.NUVORA_CONTENT.portfolioProjects : window.NUVORA_CONTENT.portfolioProjects.filter((project) => project.category === activeFilter);
  }

  function renderPortfolio(locale) {
    const root = document.querySelector('[data-portfolio-grid]');
    if (!root) return;
    root.innerHTML = visibleProjects().map((project) => projectCard(project, locale)).join('');
  }

  function renderPreview(locale) {
    const root = document.querySelector('[data-portfolio-preview-grid]');
    if (!root) return;
    root.innerHTML = window.NUVORA_CONTENT.portfolioProjects.map((project) => projectCard(project, locale)).join('');
  }

  function init(locale) {
    const controls = document.querySelectorAll('[data-portfolio-filter]');
    controls.forEach((button) => button.addEventListener('click', () => {
      controls.forEach((item) => item.classList.remove('is-active'));
      button.classList.add('is-active');
      renderPortfolio(window.NuvoraApp?.locale() || locale);
    }));
    renderPortfolio(locale);
    renderPreview(locale);
  }

  function refresh(locale) {
    renderPortfolio(locale);
    renderPreview(locale);
  }

  window.NuvoraPortfolio = { init, refresh, renderPortfolio, renderPreview };
})();
