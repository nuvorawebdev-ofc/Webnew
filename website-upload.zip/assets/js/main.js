(function () {
  const T = window.NUVORA_TRANSLATIONS;
  const CONTENT = window.NUVORA_CONTENT;

  function locale() { return document.body.dataset.lang === 'en' ? T.en : T.id; }
  function langCode() { return document.body.dataset.lang === 'en' ? 'en' : 'id'; }
  function route(route) { return window.NuvoraLanguage.routeFor(langCode(), route); }
  function whatsapp(context) {
    const copy = locale();
    const messages = {
      general: copy === T.en ? 'Hello Nuvora, I would like to discuss a website project for my business.' : 'Halo Nuvora, saya ingin mendiskusikan proyek website untuk bisnis saya.',
      website: copy === T.en ? 'Hello Nuvora, I am interested in Website Design & Development.' : 'Halo Nuvora, saya tertarik dengan layanan Desain & Pengembangan Website.',
      landing: copy === T.en ? 'Hello Nuvora, I am interested in Landing Page Development.' : 'Halo Nuvora, saya tertarik dengan layanan Pengembangan Landing Page.',
      redesign: copy === T.en ? 'Hello Nuvora, I would like to discuss a Website Redesign.' : 'Halo Nuvora, saya ingin mendiskusikan Desain Ulang Website.',
      pricing: copy === T.en ? 'Hello Nuvora, I would like to ask about the available packages and pricing.' : 'Halo Nuvora, saya ingin bertanya tentang paket dan harga yang tersedia.',
      portfolio: copy === T.en ? 'Hello Nuvora, I would like to ask about your portfolio and demo work.' : 'Halo Nuvora, saya ingin bertanya tentang portofolio dan demo website Nuvora.'
    };
    return `https://wa.me/${T.shared.phone}?text=${encodeURIComponent(messages[context] || messages.general)}`;
  }

  function setText(selector, value) { document.querySelectorAll(selector).forEach((node) => { node.textContent = value; }); }
  function hydrateStatic(copy) {
    document.querySelectorAll('[data-i18n]').forEach((node) => {
      const path = node.dataset.i18n.split('.');
      let value = copy;
      path.forEach((key) => { value = value?.[key]; });
      if (typeof value === 'string') node.textContent = value;
    });
    document.querySelectorAll('[data-i18n-attr]').forEach((node) => {
      node.dataset.i18nAttr.split(';').forEach((pair) => {
        const [attribute, path] = pair.split(':');
        let value = copy;
        path.split('.').forEach((key) => { value = value?.[key]; });
        if (typeof value === 'string') node.setAttribute(attribute, value);
      });
    });
    document.querySelectorAll('[data-i18n="footer.copyright"]').forEach((node) => {
      node.textContent = (copy.footer.copyright || '').replace('{year}', new Date().getFullYear());
    });
  }

  function renderServices(copy) {
    const root = document.querySelector('[data-services-grid]');
    if (!root) return;
    root.innerHTML = copy.services.items.map((item) => `<article class="service-card glass-panel reveal"><div class="card-index">${item.tag}</div><div><span class="eyebrow">${copy.services.eyebrow}</span><h3>${item.title}</h3><p>${item.description}</p></div><a class="text-link" data-whatsapp-context="${item.id === 'landing' ? 'landing' : item.id === 'redesign' ? 'redesign' : item.id === 'website' ? 'website' : 'general'}" href="#contact">${copy.buttons.discuss} <span aria-hidden="true">↗</span></a></article>`).join('');
  }

  function renderHeroBenefits(copy) {
    document.querySelectorAll('[data-benefit-index]').forEach((node) => {
      const index = Number(node.dataset.benefitIndex);
      if (copy.hero.benefits[index]) node.lastChild.textContent = copy.hero.benefits[index];
    });
  }

  function renderPricing(copy) {
    const root = document.querySelector('[data-pricing-grid]');
    if (!root) return;
    root.innerHTML = copy.pricing.packages.map((item) => `<article class="pricing-card glass-panel ${item.featured ? 'pricing-card--featured' : ''} reveal"><div class="pricing-card__top"><span class="eyebrow">${item.featured ? (langCode() === 'en' ? 'RECOMMENDED PRICE' : 'HARGA TERBARU') : 'NUVORA / PACKAGE'}</span><h3>${item.name}</h3><p>${item.description}</p></div><div class="price-block"><span class="price-label">${item.priceLabel}</span>${item.referencePrice ? `<span class="price-reference">${item.referencePrice}</span>` : ''}<strong>${item.price}</strong>${item.saving ? `<span class="price-saving">${item.saving}</span>` : ''}</div><ul class="feature-list">${item.features.map((feature) => `<li><span aria-hidden="true">✓</span>${feature}</li>`).join('')}</ul><a class="button ${item.featured ? 'button--lime' : 'button--ghost'}" data-whatsapp-context="pricing" href="#contact">${item.cta}<span aria-hidden="true">↗</span></a></article>`).join('');
  }

  function renderExtras(copy) {
    const root = document.querySelector('[data-extras-grid]');
    if (!root) return;
    root.innerHTML = copy.extras.items.map((item) => `<article class="extra-row reveal"><div class="extra-row__number">+</div><div><h3>${item.title}</h3><p>${item.description}</p></div><span class="extra-row__price">${item.price}</span></article>`).join('');
  }

  function renderProcess(copy) {
    const root = document.querySelector('[data-process-grid]');
    if (!root) return;
    root.innerHTML = copy.process.steps.map((step) => `<article class="process-step reveal"><span class="process-step__number">${step.number}</span><h3>${step.title}</h3><p>${step.body}</p></article>`).join('');
  }

  function renderTerms(copy) {
    const root = document.querySelector('[data-terms-content]');
    if (!root) return;
    root.innerHTML = `<article class="terms-card glass-panel reveal"><span class="eyebrow">${copy.terms.eyebrow}</span><h3>${copy.terms.paymentTitle}</h3><p>${copy.terms.paymentBody}</p></article><article class="terms-card glass-panel reveal"><span class="eyebrow">${copy.terms.eyebrow}</span><h3>${copy.terms.timelineTitle}</h3><div class="timeline-list">${copy.terms.timeline.map((item) => `<div class="timeline-row"><strong>${item.label}</strong><span>${item.value}</span></div>`).join('')}</div><p class="terms-note">${copy.terms.note}</p></article>`;
  }

  function renderFaq(copy) {
    const root = document.querySelector('[data-faq-list]');
    if (!root) return;
    root.innerHTML = copy.faq.items.map((item, index) => `<div class="faq-item" data-faq-item><button class="faq-question" data-faq-question aria-expanded="false" aria-controls="faq-answer-${index}"><span>${item.question}</span><span class="faq-plus" aria-hidden="true">+</span></button><div class="faq-answer" data-faq-answer id="faq-answer-${index}" hidden><p>${item.answer}</p></div></div>`).join('');
  }

  function renderPolicy(copy) {
    const root = document.querySelector('[data-policy-sections]');
    if (!root) return;
    root.innerHTML = copy.privacy.sections.map((item) => `<article class="policy__section reveal"><h2>${item.title}</h2><p>${item.body}</p></article>`).join('');
  }

  function bindContextualLinks() {
    document.querySelectorAll('[data-whatsapp-context]').forEach((link) => {
      const context = link.dataset.whatsappContext;
      link.href = whatsapp(context);
      link.target = '_blank';
      link.rel = 'noreferrer';
    });
    document.querySelectorAll('[data-email-link]').forEach((link) => { link.href = `mailto:${T.shared.email}`; });
    document.querySelectorAll('[data-instagram-link]').forEach((link) => { link.href = T.shared.instagramUrl; link.target = '_blank'; link.rel = 'noreferrer'; });
    document.querySelectorAll('[data-whatsapp-general]').forEach((link) => { link.href = whatsapp('general'); link.target = '_blank'; link.rel = 'noreferrer'; });
    document.querySelectorAll('[data-whatsapp-portfolio]').forEach((link) => { link.href = whatsapp('portfolio'); link.target = '_blank'; link.rel = 'noreferrer'; });
  }

  function updateMeta(copy) {
    const page = document.body.dataset.page || 'home';
    const key = page === 'privacy-policy' ? 'privacy' : page === 'thank-you' ? 'thankyou' : page === '404' ? 'notFound' : page;
    const meta = copy.meta[key] || copy.meta.home;
    document.title = meta.title;
    document.documentElement.lang = langCode();
    document.querySelector('meta[name="description"]')?.setAttribute('content', meta.description);
    document.querySelector('meta[property="og:title"]')?.setAttribute('content', meta.title);
    document.querySelector('meta[property="og:description"]')?.setAttribute('content', meta.description);
    document.querySelector('meta[name="twitter:title"]')?.setAttribute('content', meta.title);
    document.querySelector('meta[name="twitter:description"]')?.setAttribute('content', meta.description);
    const routeKey = page === 'privacy-policy' ? 'privacy' : page === 'thank-you' ? 'thankyou' : page === '404' ? 'notFound' : page;
    const path = CONTENT.routes[routeKey] || '';
    const idUrl = `${T.shared.siteUrl}/${path}`;
    const enUrl = `${T.shared.siteUrl}/en/${path}`;
    const currentUrl = langCode() === 'en' ? enUrl : idUrl;
    document.querySelectorAll('[data-canonical]').forEach((node) => { node.href = currentUrl; });
    document.querySelectorAll('meta[property="og:url"]').forEach((node) => { node.setAttribute('content', currentUrl); });
    document.querySelectorAll('link[hreflang="id"]').forEach((node) => { node.href = idUrl; });
    document.querySelectorAll('link[hreflang="en"]').forEach((node) => { node.href = enUrl; });
    document.querySelectorAll('link[hreflang="x-default"]').forEach((node) => { node.href = idUrl; });
  }

  function renderPageCopy(copy) {
    hydrateStatic(copy);
    renderHeroBenefits(copy);
    renderServices(copy);
    renderPricing(copy);
    renderExtras(copy);
    renderProcess(copy);
    renderTerms(copy);
    renderFaq(copy);
    renderPolicy(copy);
    updateMeta(copy);
    bindContextualLinks();
  }

  function init() {
    const copy = locale();
    renderPageCopy(copy);
    window.NuvoraLanguage.init();
    window.NuvoraNavigation.init();
    window.NuvoraInteractions.init();
    window.NuvoraPortfolio.init(copy);
  }

  function renderLanguage(language) {
    const copy = language === 'en' ? T.en : T.id;
    renderPageCopy(copy);
    window.NuvoraLanguage.setLanguageLinks();
    window.NuvoraPortfolio?.refresh(copy);
  }

  window.NuvoraApp = { init, locale, whatsapp, renderLanguage };
  document.addEventListener('DOMContentLoaded', init);
})();
