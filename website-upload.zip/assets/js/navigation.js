(function () {
  function init() {
    const toggle = document.querySelector('[data-menu-toggle]');
    const panel = document.querySelector('[data-menu-panel]');
    const backdrop = document.querySelector('[data-menu-backdrop]');
    if (!toggle || !panel) return;

    const close = () => {
      document.body.classList.remove('menu-open');
      toggle.setAttribute('aria-expanded', 'false');
      panel.setAttribute('aria-hidden', 'true');
    };
    const open = () => {
      document.body.classList.add('menu-open');
      toggle.setAttribute('aria-expanded', 'true');
      panel.setAttribute('aria-hidden', 'false');
      panel.querySelector('a')?.focus();
    };

    toggle.addEventListener('click', () => document.body.classList.contains('menu-open') ? close() : open());
    backdrop?.addEventListener('click', close);
    document.addEventListener('keydown', (event) => { if (event.key === 'Escape') close(); });
    panel.querySelectorAll('a').forEach((link) => link.addEventListener('click', close));
    window.addEventListener('resize', () => { if (window.innerWidth > 840) close(); });
  }

  window.NuvoraNavigation = { init };
})();
