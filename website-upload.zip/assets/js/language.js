(function () {
  const STORAGE_KEY = 'nuvora-lang';

  function cleanBase(base) {
    return base ? (base.endsWith('/') ? base : `${base}/`) : '';
  }

  function currentRoute() {
    const page = document.body.dataset.page || 'home';
    return page === 'privacy-policy' ? 'privacy' : page === 'thank-you' ? 'thankyou' : page === '404' ? 'notFound' : page;
  }

  function routeFor(language, route) {
    const base = cleanBase(document.body.dataset.base || '');
    const routes = window.NUVORA_CONTENT.routes;
    const suffix = routes[route] || '';
    return `${base}${language === 'en' ? 'en/' : ''}${suffix}` || './';
  }

  function save(language) {
    try { localStorage.setItem(STORAGE_KEY, language); } catch (error) { /* storage may be blocked */ }
  }

  function read() {
    try {
      const value = localStorage.getItem(STORAGE_KEY);
      return value === 'en' || value === 'id' ? value : null;
    } catch (error) {
      return null;
    }
  }

  function setLanguageLinks() {
    const route = currentRoute();
    document.querySelectorAll('[data-language-link]').forEach((link) => {
      const target = link.dataset.languageLink;
      link.href = routeFor(target, route);
      link.setAttribute('aria-current', target === document.body.dataset.lang ? 'true' : 'false');
    });
  }

  function init() {
    const active = document.body.dataset.lang || 'id';
    setLanguageLinks();
    document.querySelectorAll('[data-language-link]').forEach((link) => {
      link.addEventListener('click', (event) => {
        const target = link.dataset.languageLink;
        if (target === document.body.dataset.lang) return;
        event.preventDefault();
        save(target);
        document.body.dataset.lang = target;
        window.NuvoraApp?.renderLanguage(target);
      });
    });
    document.querySelectorAll('[data-lang-label]').forEach((node) => {
      node.textContent = active === 'id' ? 'ID' : 'EN';
    });
  }

  window.NuvoraLanguage = { STORAGE_KEY, routeFor, save, read, init, setLanguageLinks };
})();
